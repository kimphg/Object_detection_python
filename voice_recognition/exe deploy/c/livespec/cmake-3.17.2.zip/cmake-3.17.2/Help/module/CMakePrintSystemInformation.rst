.. cmake-module:: ../../Modules/CMakePrintSystemInformation.cmake
