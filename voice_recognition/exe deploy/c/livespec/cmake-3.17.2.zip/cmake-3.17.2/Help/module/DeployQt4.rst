.. cmake-module:: ../../Modules/DeployQt4.cmake
